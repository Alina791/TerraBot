package animals;

import fileio.AnimalInput;
import entities.Animal;

public class Carnivore extends Animal {
    private static final double MAX_ATTACK = 100.0;
    private static final double ATTACK_POSSIBILITY = 30.0;
    private static final double DIVISOR = 10.0;

    public Carnivore(final String name, final double mass) {
        super(name, mass, "Carnivores");
    }
    public Carnivore(final AnimalInput input) {
        super(input);
    }

    /** Calculates the probability for the robot to get attacked
     * by this animal.
     */
    public double calculateAttackProbability() {
        return (MAX_ATTACK - ATTACK_POSSIBILITY) / DIVISOR;
    }
}
